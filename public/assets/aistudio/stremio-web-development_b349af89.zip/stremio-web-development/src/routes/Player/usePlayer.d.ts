// Copyright (C) 2017-2026 Smart code 203358507

declare const usePlayer: (urlParams: UrlParams) => [
    Player,
    videoParamsChanged: (videoParams: { hash: string | null, size: number | null, filename: string | null }) => void,
    streamStateChanged: (state: Partial<StreamState>) => void,
    audioPreferenceChanged: (preference: AudioPreference) => void,
    subtitlePreferenceChanged: (preference: SubtitlePreference) => void,
    videoScaleChanged: (videoScale: VideoScale) => void,
    timeChanged: (time: number, duration: number | null, device: string) => void,
    seek: (time: number, duration: number, device: string) => void,
    pausedChanged: (paused: boolean) => void,
    ended: () => void,
    nextVideo: () => void,
];

export = usePlayer;
