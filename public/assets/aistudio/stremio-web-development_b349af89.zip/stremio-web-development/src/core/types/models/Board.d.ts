type Board = CatalogsWithExtra;
