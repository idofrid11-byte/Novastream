// Copyright (C) 2017-2024 Smart code 203358507

import React, { useRef, useEffect, useCallback } from 'react';
import { Button } from 'stremio/components';
import { useTranslation } from 'react-i18next';
import classNames from 'classnames';
import Option from './Option';
import Icon from '@stremio/stremio-icons/react';
import { getInterfaceRect } from 'stremio/common/interfaceScale';
import styles from './Dropdown.less';

type Props = {
    options: MultiselectMenuOption[];
    value?: any;
    menuOpen: boolean | (() => void);
    level: number;
    setLevel: (level: number) => void;
    onSelect: (value: any) => void;
};

const Dropdown = ({ level, setLevel, options, onSelect, value, menuOpen }: Props) => {
    const { t } = useTranslation();
    const optionsRef = useRef(new Map());
    const containerRef = useRef<HTMLDivElement>(null);
    const selectedOptionValue = options.find((opt) => opt.value === value)?.value;

    const handleSetOptionRef = useCallback((optionValue: any) => (node: HTMLButtonElement | null) => {
        if (node) {
            optionsRef.current.set(optionValue, node);
        } else {
            optionsRef.current.delete(optionValue);
        }
    }, []);

    const handleBackClick = useCallback(() => {
        setLevel(level - 1);
    }, [setLevel, level]);

    useEffect(() => {
        const container = containerRef.current;
        if (!menuOpen || selectedOptionValue === undefined || !container) return;
        const selectedNode = optionsRef.current.get(selectedOptionValue);
        if (!selectedNode) return;
        const listBounds = getInterfaceRect(container);
        const optionBounds = getInterfaceRect(selectedNode);
        if (optionBounds.top < listBounds.top || optionBounds.bottom > listBounds.bottom) {
            container.scrollBy({ top: optionBounds.top - listBounds.top, behavior: 'smooth' });
        }
    }, [menuOpen, selectedOptionValue]);

    return (
        <div
            className={classNames(styles['dropdown'], { [styles['open']]: menuOpen })}
            role={'listbox'}
            ref={containerRef}
        >
            {level > 0 ?
                <Button className={styles['back-button']} onClick={handleBackClick}>
                    <Icon name={'caret-left'} className={styles['back-button-icon']} />
                    {t('BACK')}
                </Button>
                : null
            }
            {options
                .filter((option: MultiselectMenuOption) => !option.hidden)
                .map((option: MultiselectMenuOption) => (
                    <Option
                        key={option.value}
                        ref={handleSetOptionRef(option.value)}
                        option={option}
                        onSelect={onSelect}
                        selectedValue={value}
                    />
                ))
            }
        </div>
    );
};

export default Dropdown;
